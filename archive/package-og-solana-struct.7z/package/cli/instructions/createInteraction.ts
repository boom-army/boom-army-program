import * as Layout from "../layout";
import { Buffer } from "buffer";
import {
  Connection,
  Keypair,
  PublicKey,
  Signer,
  SystemProgram,
  Transaction,
  TransactionInstruction,
} from "@solana/web3.js";
import { SOSOL_PROGRAM_ID, SOSOL_TOKEN_ID } from "../constants";
import {
  Token,
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  AccountLayout,
} from "@solana/spl-token";
import { sendAndConfirmTransaction } from "../sendAndConfirmTransaction";
import { newAccountWithLamports } from "../index";
// @ts-ignore
import { struct, u8 } from "buffer-layout";

interface Data {
  instruction: number;
  interactionFee: bigint;
}

const dataLayout = struct<Data>([
  u8("instruction"),
  Layout.u64("interactionFee"),
]);

/**
 * Create an interaction payment from consumer to the contentcreator and storage host
 *
 * @param connection The connection to use
 * @param consumerAccount The account of the content consumer
 * @param consumerPayAccKey The account shared by the consumer and program
 * @param creatorAccount The account of the contents creator/owner
 * @param interactionFee The fee for the consumer
 * @param storagePercentFee The percentage allocation of the `interactionFee` to the storage host as a decimal between 0-1 eg. 0.15
 * @param storageAccount The account of the content provider where the content is stored
 */
const createInteractionInstruction = (
  consumerAccount: Keypair,
  consumerTokenAccKey: PublicKey,
  creatorTokenKey: PublicKey,
  storageTokenKey: PublicKey,
  interactionFee: number
): TransactionInstruction => {
  const data = Buffer.alloc(dataLayout.span);
  dataLayout.encode(
    {
      instruction: 0,
      interactionFee: BigInt(interactionFee),
    },
    data
  );

  const keys = [
    { pubkey: consumerAccount.publicKey, isSigner: true, isWritable: true },
    { pubkey: consumerTokenAccKey, isSigner: true, isWritable: true },
    { pubkey: creatorTokenKey, isSigner: false, isWritable: true },
    { pubkey: storageTokenKey, isSigner: false, isWritable: true },
    { pubkey: SOSOL_TOKEN_ID, isSigner: false, isWritable: false },
    { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
  ];

  return new TransactionInstruction({
    keys,
    programId: SOSOL_PROGRAM_ID,
    data,
  });
};

export async function createInteraction(
  connection: Connection,
  consumer: Keypair,
  creatorKey: PublicKey,
  storageKey: PublicKey,
  interactionFee: number,
): Promise<string> {
  console.log("Fetching SOSOL mint");
  // const sosolToken = new Token(
  //   connection,
  //   SOSOL_TOKEN_ID,
  //   TOKEN_PROGRAM_ID,
  //   consumer
  // );

  // //create new token mint
  // let mint = await sosolToken.mintTo(
  //   consumer.publicKey,
  //   consumer,
  //   [],
  //   42000,
  // );


  //create new token mint
  let sosolToken = await Token.createMint(
    connection,
    consumer,
    consumer.publicKey,
    null,
    9,
    TOKEN_PROGRAM_ID,
  );
  let consumerTokenAcc = await sosolToken.getOrCreateAssociatedAccountInfo(
    consumer.publicKey,
  );
  sosolToken.mintTo(consumerTokenAcc.address, consumer.publicKey, [], 4200000000000000)

  console.log(`token account: ${consumerTokenAcc.address.toBase58()}, token: ${sosolToken.publicKey.toBase58()}`);
  
  console.log("Fetching creator token account");
  const creatorTokenAcc = await sosolToken.getOrCreateAssociatedAccountInfo(
    creatorKey,
  );
  console.log(`Creator account key: ${creatorKey}, token account key: , ${creatorTokenAcc.address.toBase58()}`);

  console.log("Fetching consumer token account");
  const storageTokenAcc = await sosolToken.getOrCreateAssociatedAccountInfo(
    storageKey,
  );
  console.log(`Consumer account key: ${storageKey}, token account key: , ${storageTokenAcc.address.toBase58()}`);

  const transaction = new Transaction();

  transaction.add(
    createInteractionInstruction(
      consumer,
      consumerTokenAcc.address,
      creatorTokenAcc.address,
      storageTokenAcc.address,
      interactionFee
    )
  );

  // Send the instructions
  console.log("sending create interaction instruction");
  return await sendAndConfirmTransaction(
    "create account, approve transfer, swap",
    connection,
    transaction,
    consumer,
  );
}
